import json
import boto3
import requests

# Initialize SNS client
sns_client = boto3.client('sns')

# List of health check URLs
URLS = [
    ""
]

# SNS Topic ARN (Replace with your actual SNS Topic ARN)
SNS_TOPIC_ARN = "arn:aws:sns:us-west-2:490047155434:tm-backend-url-endpoint-health-checker-sns"

def check_health_status():
    """Check health status of URLs and return unhealthy ones."""
    unhealthy_urls = []
    
    for url in URLS:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code != 200:
                unhealthy_urls.append((url, response.status_code))
        except requests.RequestException as e:
            unhealthy_urls.append((url, str(e)))
    
    return unhealthy_urls

def send_sns_notification(unhealthy_urls):
    """Send SNS notification if any URL is down."""
    message = "🚨 Health Check Alert! 🚨\n\nThe following services are down:\n"
    
    for url, status in unhealthy_urls:
        message += f"- {url} (Status: {status})\n"
    
    response = sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message=message,
        Subject="Health Check Alert: Services Down"
    )
    
    return response

def lambda_handler(event, context):
    """AWS Lambda handler."""
    unhealthy_urls = check_health_status()
    
    if unhealthy_urls:
        send_sns_notification(unhealthy_urls)
    
    return {
        "statusCode": 200,
        "body": json.dumps({"unhealthy_urls": unhealthy_urls})
    }
